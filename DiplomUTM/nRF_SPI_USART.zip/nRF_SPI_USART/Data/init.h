

#ifndef INIT_H
#define INIT_H

void init(void);


#endif