﻿
#include "define.h"
#include "bits_macros.h"
#include "nRF24L01.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h> 

#define BUF_SIZE 256
static uint8_t buff_RX[BUF_SIZE], IN_RX, OUT_RX;//тут у нас буфер в который складываем принимаемые данные до 256 байт
static uint8_t buff_TX[BUF_SIZE], IN_TX, OUT_TX;;//А сюда кладем данные для отправки до 256 байт

static uint8_t C0,C1,C2,F1,F2,F3;


ISR(USART_RXC_vect)//Прерывание по приему байта. 
{
	SetBit(PORTB,RX);//синий диод.
	buff_TX[IN_TX++]=UDR;//помещаем данные в кольцевой буфер.
}

ISR(USART_UDRE_vect)//Прерывание по опустошению буфра UDR отправка
{
	SetBit(PORTB,TX);//зеленый диод
	UDR=buff_RX[OUT_RX++];
	if (IN_RX == OUT_RX)//указатель конца достиг указателя начала, буфер пуст.
	{
		ClearBit(UCSRB,UDRIE);//выкл прерывание по опустошнию UDR.
	}
}

ISR(TIMER0_OVF_vect)//Прерывание по переполнению Timer 0
{
	TCNT0=0x8D;
	
	#if 1 //LEDS выключаем светодиоды
		if (BitIsSet(PORTD,SPI))
		{
			C0++;
		}
		if (C0>=5)
		{
			ClearBit(PORTD,SPI);
			C0=0;
		}
		
		if (BitIsSet(PORTB,RX))
		{
			C1++;
		}
		if (C1>=50)
		{
			ClearBit(PORTB,RX);
			C1=0;
		}
		
		if (BitIsSet(PORTB,TX))
		{
			C2++;
		}
		if (C2>=5)
		{
			ClearBit(PORTB,TX);
			C2=0;
		}
	#endif
}

void main_cod (void)
{
	if (IN_TX != OUT_TX)
	{
		send_byte(buff_TX[OUT_TX++]);
	}
		
	if (BitIsClear(PINC,IRQ))
	{
		uint8_t a= r_register(STATUS);//прочитали статус регистр
		w_register(STATUS, a);//сброс флагов прерываний - обязательно
		if (BitIsSet(a,RX_DR))
		{
			uint8_t a =IN_RX;
			buff_RX[IN_RX++]=r_register(R_RX_PAYLOAD);//чтение 1 байта из буфера приема RX_FIFO в озу buff и отправка в USART.
			if (buff_RX[a]==0xAA)
			{
				F1=1;
			}
			else if (buff_RX[a]==0xBB)
			{
				F1=2;
			}
		}
	}
	
	if (IN_RX != OUT_RX)
	{
		SetBit(UCSRB,UDRIE);//вкл прерывание по опустошнию UDR.
	}
	//======================================================================
	//тут мы просто выключаем загоревшиеся светодиоды.
	if (F1==1)
	{
		F1=0;
		InvBit(PORTC,PC3);
	}
	else if (F1==2)
	{
		F1=0;
		InvBit(PORTC,PC2);
	}
	
	if (BitIsClear(PINC,PC5) && F2==0)
	{
		_delay_ms(100);
		F2=1;
		send_byte(0xAA);
	} 
	else if(BitIsSet(PINC,PC5) && F2==1)
	{
		_delay_ms(50);
		F2=0;
	}
	
	if (BitIsClear(PINC,PC4) && F3==0)
	{
		_delay_ms(100);
		F3=1;
		send_byte(0xBB);
	}
	else if(BitIsSet(PINC,PC4) && F3==1)
	{
		_delay_ms(50);
		F3=0;
	}
	
}

//компьютер->>buff_TX ->> SPI    ->>SPI ->> buff_RX ->> компьютер