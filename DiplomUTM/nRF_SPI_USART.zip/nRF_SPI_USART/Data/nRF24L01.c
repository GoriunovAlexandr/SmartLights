﻿
#include "define.h"
#include "bits_macros.h"
#include "nRF24L01.h"
#include <avr/io.h>
#include <util/delay.h> //_delay_us(5);_delay_ms(5);


void w_register(uint8_t a,uint8_t b)//а-адрес регистра, b-что пишем в регистр.
{
	a=a | W_REGISTER;
	SetBit(PORTD,SPI);//красный диод.
	ClearBit(PORTB,CSN);
	SPDR=a;
	while(BitIsClear(SPSR,SPIF));
	if (b==0 && a!=W_TX_PAYLOAD)
	{
		a=SPDR;//для сброса флага SPIF
		SetBit(PORTB,CSN);
		return;
	}
	SPDR=b;
	while(BitIsClear(SPSR,SPIF));
	a=SPDR;//для сброса флага SPIF
	SetBit(PORTB,CSN);
}//W_REGISTER (CONFIG,0b00000110);
uint8_t r_register(uint8_t a)//чтение байта из озу. a-адрес байта
{
	ClearBit(PORTB,CSN);//Прижимаем вывод CSN(SS) МК к земле, тем самым сообщаем о начале обмена данных.
	SetBit(PORTD,SPI);//красный диод.
	SPDR=a;
	while(BitIsClear(SPSR,SPIF));//ожидаем когда освободится SPI для последующей записи байта
	if (a==STATUS)
	{
		SetBit(PORTB,CSN);//Вывод CSN(SS) МК к питанию, обмен данных завершен.
		return SPDR;
	}
	SPDR=NOP;
	while(BitIsClear(SPSR,SPIF));
	SetBit(PORTB,CSN);//Вывод CSN(SS) МК к питанию, обмен данных завершен.
	return SPDR;
}//uint8_t a=r_register(EN_AA);
void prx(void)//Настроим nRF на прием.
{
	w_register(CONFIG,(1<<PWR_UP)|(1<<EN_CRC)|(1<<PRIM_RX));
	SetBit(PORTC,CE);
	_delay_us(135);
	//режим према RX
}
void ptx(void)//Настроим nRF на передачу.
{
	ClearBit(PORTC,CE);
	w_register(CONFIG,(1<<PWR_UP)|(1<<EN_CRC)|(0<<PRIM_RX));
	SetBit(PORTC,CE);
	_delay_us(15);
	ClearBit(PORTC,CE);
	_delay_us(135);
	
}
void send_byte(uint8_t a)//отправка байта.
{
	w_register(W_TX_PAYLOAD,a);//запись байта в буфер TX для отправки
	ptx();//передача байта
	while (BitIsSet(PINC,IRQ));//Ждем пока байт не передан
	uint8_t b= r_register(STATUS);//прочитали статус регистр
	w_register(STATUS, b);//сброс флагов прерываний - обязательно
	prx();//на прием
	
}

