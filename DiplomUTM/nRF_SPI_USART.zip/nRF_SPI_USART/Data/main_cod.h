﻿


#ifndef MAIN_COD_H_
#define MAIN_COD_H_


void main_cod(void);


#endif /* MAIN_COD_H_ */